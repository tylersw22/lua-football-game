-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

require("physics")
physics.start()
physics.setGravity(0,0)

function loadbackground()
	local background = display.newImageRect( "background.jpg", 360, 570 )
	background.x = display.contentCenterX
	background.y = display.contentCenterY
end

function loadobjects()
	ball = display.newCircle( 160, 250, 20 )	
	ball:setFillColor(255, 255, 255)
	physics.addBody(ball, "dynamic", {friction=0, bounce = 0, radius=20})
	obstacle= display.newRect(150,50,100,10)
	obstacle:setFillColor(255, 255, 255)
	physics.addBody(obstacle, "dynamic", {friction=1, bounce = 1})
	obstacle.isFixedRotation = true
	if (goalcount==0) then
		obstacle:setLinearVelocity(100,0)
	elseif (goalcount==1) then
		obstacle:setLinearVelocity(200,0)
		obstacle:setFillColor(0, 255, 0)
	elseif (goalcount==2) then
		obstacle:setLinearVelocity(300,0)
		obstacle:setFillColor(0, 0, 255)
	elseif (goalcount==3) then
		obstacle:setLinearVelocity(400,0)
		obstacle:setFillColor(255, 0, 0)
	elseif (goalcount==4) then
		obstacle:setLinearVelocity(450,0)
		obstacle:setFillColor(0, 0, 0)
	else
		reset()
	end
	ball:addEventListener("tap",tap)
	leftborder:addEventListener("collision", VoidBorderCollision)
	rightborder:addEventListener("collision", VoidBorderCollision)
	obstacle:addEventListener("collision", miss)
end 

function loadborders()
	leftborder= display.newRect(0,0,1,display.contentHeight)
	leftborder:setFillColor(255, 255, 255)
	physics.addBody(leftborder, "static", {friction=0, bounce = 1})
	rightborder= display.newRect(display.contentWidth,0,1,display.contentHeight)
	rightborder:setFillColor(255, 255, 255)
	physics.addBody(rightborder, "static", {friction=0, bounce = 1})
	topborder= display.newRect(0,-12,display.contentWidth*2,1)
	topborder:setFillColor(255, 255, 255)
	physics.addBody(topborder, "static", {friction=0, bounce = 0})
end

function counter()
	goalcount=0
	goaltext=display.newText(goalcount,display.contentCenterX,350, native.systemFont,60)
	
end

function tap()
	ball:setLinearVelocity(0,-800)
end

function reset()
	display.remove(obstacle)
	display.remove(ball)
end

function goal()
	goalcount=goalcount+1
	display.remove(goaltext)
	if (goalcount==5) then
		goaltext=display.newText("you win",display.contentCenterX,350, native.systemFont,60)
		timer.performWithDelay(1000, endgame)
	else
		goaltext=display.newText(goalcount,display.contentCenterX,350, native.systemFont,60)
	end
	reset()
	timer.performWithDelay(1000, loadobjects)
end

function miss()
	if (x~=1) then
	goalcount=0
	display.remove(goaltext)
	goaltext=display.newText(goalcount,display.contentCenterX,350, native.systemFont,60)
	reset()
	timer.performWithDelay(1000, loadobjects)
	else
	x=0
	end
end

function VoidBorderCollision()
	x=1
end

function endgame()
	native.requestExit()
end

loadbackground()
loadborders()
counter()
reset()
loadobjects()

topborder:addEventListener("collision", goal)








	



